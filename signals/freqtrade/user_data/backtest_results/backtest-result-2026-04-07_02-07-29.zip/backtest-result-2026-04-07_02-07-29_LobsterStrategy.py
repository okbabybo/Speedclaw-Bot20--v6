# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401

from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
import numpy as np


class LobsterStrategy(IStrategy):
    """
    混沌龙虾·优化策略 v2.0
    """

    timeframe = "1h"
    stoploss = -0.05
    minimal_roi = {
        "0": 0.03,
        "60": 0.02,
        "180": 0.015,
    }

    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.015
    trailing_only_offset_is_reached = True

    stoploss_timeout = 180
    exit_only_on_signal = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['ema20'] = ta.EMA(dataframe, timeperiod=20)
        dataframe['ema50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_fast'] = ta.RSI(dataframe, timeperiod=7)

        macd = ta.MACD(dataframe)
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['macdsignal']
        dataframe['macdhist'] = macd['macdhist']

        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_upper'] = bollinger['upperband']
        dataframe['bb_lower'] = bollinger['lowerband']
        dataframe['bb_middle'] = bollinger['middleband']

        dataframe['volume_ma'] = ta.SMA(dataframe, timeperiod=20)
        dataframe['volume_ratio'] = dataframe['volume'] / dataframe['volume_ma']

        dataframe['uptrend'] = (
            (dataframe['close'] > dataframe['ema20']) &
            (dataframe['close'] > dataframe['ema50'])
        ).astype(int)

        dataframe['downtrend'] = (
            (dataframe['close'] < dataframe['ema20']) &
            (dataframe['close'] < dataframe['ema50'])
        ).astype(int)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['uptrend'] == 1) &
                ((dataframe['rsi'] < 35) | (dataframe['rsi_fast'] < 40)) &
                (dataframe['macdhist'] > 0) &
                (dataframe['volume_ratio'] > 1.0) &
                (dataframe['close'] > dataframe['bb_lower'] * 0.98)
            ),
            'enter_long'] = 1

        dataframe.loc[
            (
                (dataframe['downtrend'] == 1) &
                ((dataframe['rsi'] > 65) | (dataframe['rsi_fast'] > 60)) &
                (dataframe['macdhist'] < 0) &
                (dataframe['volume_ratio'] > 1.0) &
                (dataframe['close'] < dataframe['bb_upper'] * 1.02)
            ),
            'enter_short'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['rsi'] > 75) |
                ((dataframe['macdsignal'] < dataframe['macd']) & (dataframe['macdhist'] < 0))
            ),
            'exit_long'
        ] = 1

        dataframe.loc[
            (
                (dataframe['rsi'] < 25) |
                ((dataframe['macdsignal'] > dataframe['macd']) & (dataframe['macdhist'] > 0))
            ),
            'exit_short'
        ] = 1

        return dataframe
