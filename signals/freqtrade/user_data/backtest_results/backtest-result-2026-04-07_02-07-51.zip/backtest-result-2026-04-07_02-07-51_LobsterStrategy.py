# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401

from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class LobsterStrategy(IStrategy):
    """
    混沌龙虾·优化策略 v3.0
    简化版，让回测跑起来
    """

    timeframe = "1h"
    stoploss = -0.05
    minimal_roi = {
        "0": 0.02,
        "60": 0.015,
    }

    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.01
    trailing_only_offset_is_reached = True

    exit_only_on_signal = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['ema20'] = ta.EMA(dataframe, timeperiod=20)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        macd = ta.MACD(dataframe)
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['macdsignal']

        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_upper'] = bollinger['upperband']
        dataframe['bb_lower'] = bollinger['lowerband']

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 做多信号
        dataframe.loc[
            (
                (dataframe['close'] > dataframe['ema20']) &
                (dataframe['rsi'] < 40) &
                (dataframe['macd'] > dataframe['macdsignal']) &
                (dataframe['close'] < dataframe['bb_lower'])
            ),
            'enter_long'] = 1

        # 做空信号
        dataframe.loc[
            (
                (dataframe['close'] < dataframe['ema20']) &
                (dataframe['rsi'] > 60) &
                (dataframe['macd'] < dataframe['macdsignal']) &
                (dataframe['close'] > dataframe['bb_upper'])
            ),
            'enter_short'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['rsi'] > 70),
            'exit_long'
        ] = 1

        dataframe.loc[
            (dataframe['rsi'] < 30),
            'exit_short'
        ] = 1

        return dataframe
