# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401

from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class LobsterStrategy(IStrategy):
    """
    混沌龙虾·优化策略 v5.0
    极简版：RSI买卖
    """

    timeframe = "1h"
    stoploss = -0.05
    minimal_roi = {
        "0": 0.02,
    }

    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.01
    trailing_only_offset_is_reached = True

    exit_only_on_signal = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 做多：RSI < 30
        dataframe.loc[
            (dataframe['rsi'] < 30),
            'enter_long'
        ] = 1

        # 做空：RSI > 70
        dataframe.loc[
            (dataframe['rsi'] > 70),
            'enter_short'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe
