# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401

from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class LobsterStrategy(IStrategy):
    """
    混沌龙虾·优化策略 v4.0
    优化点：
    1. 简化条件，提高信号率
    2. RSI超买超卖为核心
    3. 趋势确认辅助
    """

    timeframe = "1h"
    stoploss = -0.05
    minimal_roi = {
        "0": 0.02,
        "60": 0.015,
    }

    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.015
    trailing_only_offset_is_reached = True

    exit_only_on_signal = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMA趋势
        dataframe['ema20'] = ta.EMA(dataframe, timeperiod=20)
        dataframe['ema50'] = ta.EMA(dataframe, timeperiod=50)
        
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        
        # MACD
        macd = ta.MACD(dataframe)
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['macdsignal']
        
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 做多：RSI超卖 + 趋势向上
        dataframe.loc[
            (
                (dataframe['rsi'] < 35) &
                (dataframe['close'] > dataframe['ema20']) &
                (dataframe['macd'] > dataframe['macdsignal'])
            ),
            'enter_long'
        ] = 1

        # 做空：RSI超买 + 趋势向下
        dataframe.loc[
            (
                (dataframe['rsi'] > 65) &
                (dataframe['close'] < dataframe['ema20']) &
                (dataframe['macd'] < dataframe['macdsignal'])
            ),
            'enter_short'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 退出：RSI回归中性
        dataframe.loc[
            (dataframe['rsi'] > 60),
            'exit_long'
        ] = 1

        dataframe.loc[
            (dataframe['rsi'] < 40),
            'exit_short'
        ] = 1

        return dataframe
