# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401

import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime, timedelta, timezone
from typing import Optional, Union

from freqtrade.strategy import (
    IStrategy,
    Trade,
    Order,
    PairLocks,
    informative,
    BooleanParameter,
    CategoricalParameter,
    DecimalParameter,
    IntParameter,
    RealParameter,
    timeframe_to_minutes,
    timeframe_to_next_date,
    timeframe_to_prev_date,
    merge_informative_pair,
    stoploss_from_absolute,
    stoploss_from_open,
)

import talib.abstract as ta
from technical import qtpylib


class LobsterStrategy(IStrategy):
    """
    混沌龙虾·优化策略 v7.0
    基于SampleStrategy + 我们的规则：
    1. RSI交叉信号（不是简单比较）
    2. TEMA趋势确认
    3. BOLL区间确认
    4. 成交量确认
    """

    INTERFACE_VERSION = 3

    can_short: bool = False

    # 止损 -5%（我们的是5%）
    stoploss = -0.05

    # ROI
    minimal_roi = {
        "0": 0.02,
        "60": 0.015,
    }

    # 追踪止损开启
    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.015
    trailing_only_offset_is_reached = True

    # 我们的参数
    buy_rsi = IntParameter(low=30, high=50, default=35, space="buy", optimize=True, load=True)
    sell_rsi = IntParameter(low=50, high=70, default=65, space="sell", optimize=True, load=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # TEMA
        dataframe['tema'] = ta.TEMA(dataframe, timeperiod=20)

        # BOLL
        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_middleband'] = bollinger['middleband']

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 做多：RSI交叉向上 + TEMA在BOLL中轨下方 + TEMA向上
        dataframe.loc[
            (
                (qtpylib.crossed_above(dataframe["rsi"], self.buy_rsi.value)) &
                (dataframe["tema"] <= dataframe["bb_middleband"]) &
                (dataframe["tema"] > dataframe["tema"].shift(1)) &
                (dataframe["volume"] > 0)
            ),
            'enter_long'
        ] = 1

        # 做空：RSI交叉向下 + TEMA在BOLL中轨上方 + TEMA向下
        dataframe.loc[
            (
                (dataframe["rsi"] > self.sell_rsi.value) &
                (dataframe["tema"] > dataframe["bb_middleband"]) &
                (dataframe["tema"] < dataframe["tema"].shift(1)) &
                (dataframe["volume"] > 0)
            ),
            'enter_short'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['rsi'] > self.sell_rsi.value),
            'exit_long'
        ] = 1

        return dataframe
