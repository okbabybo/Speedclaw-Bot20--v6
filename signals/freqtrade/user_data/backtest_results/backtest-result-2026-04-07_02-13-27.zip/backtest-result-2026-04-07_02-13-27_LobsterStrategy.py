# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401

from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class LobsterStrategy(IStrategy):
    """
    混沌龙虾·优化策略 v6.0
    结合我们的规则 + SampleStrategy框架：
    1. RSI超买超卖为核心
    2. EMA趋势确认
    3. MACD方向确认
    4. 多指标共振
    """

    timeframe = "1h"
    stoploss = -0.05
    minimal_roi = {
        "0": 0.02,
        "60": 0.015,
    }

    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.015
    trailing_only_offset_is_reached = True

    exit_only_on_signal = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        
        # EMA趋势
        dataframe['ema20'] = ta.EMA(dataframe, timeperiod=20)
        dataframe['ema50'] = ta.EMA(dataframe, timeperiod=50)
        
        # MACD
        macd = ta.MACD(dataframe)
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['macdsignal']
        
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 做多：RSI < 35 + EMA趋势向上 + MACD确认
        dataframe.loc[
            (
                (dataframe['rsi'] < 35) &
                (dataframe['close'] > dataframe['ema20']) &
                (dataframe['macd'] > dataframe['macdsignal'])
            ),
            'enter_long'
        ] = 1

        # 做空：RSI > 65 + EMA趋势向下 + MACD确认
        dataframe.loc[
            (
                (dataframe['rsi'] > 65) &
                (dataframe['close'] < dataframe['ema20']) &
                (dataframe['macd'] < dataframe['macdsignal'])
            ),
            'enter_short'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 退出：RSI回归中性
        dataframe.loc[
            (dataframe['rsi'] > 60),
            'exit_long'
        ] = 1

        dataframe.loc[
            (dataframe['rsi'] < 40),
            'exit_short'
        ] = 1

        return dataframe
